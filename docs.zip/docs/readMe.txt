Serverge juktolgondon kiyi
gettext ornotush kerek

sudo apt install gettext
